# ESP32 firmware integration contract

The Android app expects an ESP32 BLE peripheral with the following GATT service:

- Service: `7f510001-1b15-4f0a-9a2b-6f4a524f4345`
- Command characteristic (WRITE): `7f510002-1b15-4f0a-9a2b-6f4a524f4345`
- Advertised device name must contain `ESP32` or `JARVIS`.

Current command:
`DISCONNECT:<MAC_ADDRESS>`

The app only transmits this command to the paired/connected ESP32 GATT service. Firmware must validate that the target is an owner-authorized device and implement only a supported, standards-compliant control operation. A BLE scan result alone does not grant control over a device. Do not attempt to jam, interfere with, or forcibly disconnect third-party devices.

The present Android app does not yet receive a streamed device list from the ESP32; its scanner uses the Android phone's BLE scanner. A later firmware/app revision can add a NOTIFY characteristic for ESP32-originated scan results and OLED/trigger status.
