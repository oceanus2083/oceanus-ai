package com.jarvisoceanus.lab

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.UUID

private val Navy = Color(0xFF061426)
private val Panel = Color(0xFF0D2139)
private val Cyan = Color(0xFF16BFFF)
private val Green = Color(0xFF20E58A)
private val Muted = Color(0xFF9BB8D4)

data class SeenDevice(val name: String, val address: String, val rssi: Int)

class MainActivity : ComponentActivity() {
    private val adapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
    }
    private val found = mutableStateListOf<SeenDevice>()
    private var scanning by mutableStateOf(false)
    private var espConnected by mutableStateOf(false)
    private var selected by mutableStateOf<SeenDevice?>(null)
    private var statusMessage by mutableStateOf("Ready. Grant Bluetooth permission to begin.")
    private var gatt: BluetoothGatt? = null

    private val serviceId = UUID.fromString("7f510001-1b15-4f0a-9a2b-6f4a524f4345")
    private val commandId = UUID.fromString("7f510002-1b15-4f0a-9a2b-6f4a524f4345")

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) startScan()
        else statusMessage = "Bluetooth permission is required to scan."
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = try { device.name ?: result.scanRecord?.deviceName ?: "Unknown BLE device" }
                       catch (_: SecurityException) { "BLE device" }
            val item = SeenDevice(name, device.address, result.rssi)
            val index = found.indexOfFirst { it.address == item.address }
            if (index >= 0) found[index] = item else if (found.size < 60) found.add(item)
            found.sortByDescending { it.rssi }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            statusMessage = "Scan failed ($errorCode). Check Bluetooth is enabled."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, secondary = Green, background = Navy, surface = Panel
            )) {
                OceanusApp(
                    devices = found.toList(),
                    scanning = scanning,
                    espConnected = espConnected,
                    selected = selected,
                    status = statusMessage,
                    onScan = { ensurePermissionsAndScan() },
                    onSelect = { selected = it },
                    onConnectEsp = { connectToEsp32() },
                    onDisconnectTarget = { requestTargetDisconnect() },
                    onReconnect = { statusMessage = "Reconnect request is not available until ESP32 firmware supports the target device protocol." }
                )
            }
        }
    }

    private fun hasPermissions(): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun ensurePermissionsAndScan() {
        if (!hasPermissions()) {
            val needed = if (Build.VERSION.SDK_INT >= 31)
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            permissionLauncher.launch(needed)
        } else startScan()
    }

    @Suppress("MissingPermission")
    private fun startScan() {
        val scanner = adapter?.bluetoothLeScanner
        if (scanner == null) {
            statusMessage = "Bluetooth is off or BLE scanning is unavailable."
            return
        }
        try {
            scanner.stopScan(scanCallback)
            found.clear()
            scanner.startScan(scanCallback)
            scanning = true
            statusMessage = "Scanning nearby BLE advertisements. Classic-only audio devices may not appear."
            window.decorView.postDelayed({
                try { scanner.stopScan(scanCallback) } catch (_: Exception) {}
                scanning = false
                statusMessage = "Scan complete. Select a device to inspect its signal."
            }, 10000)
        } catch (e: SecurityException) {
            statusMessage = "Bluetooth permission was denied."
        }
    }

    @Suppress("MissingPermission")
    private fun connectToEsp32() {
        if (!hasPermissions()) { ensurePermissionsAndScan(); return }
        val esp = found.firstOrNull {
            it.name.contains("ESP32", true) || it.name.contains("JARVIS", true)
        }
        if (esp == null) {
            statusMessage = "No ESP32/JARVIS BLE advertisement found. Power on the ESP32 and scan again."
            return
        }
        try {
            val device = adapter?.getRemoteDevice(esp.address) ?: return
            gatt?.close()
            gatt = device.connectGatt(this, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                    runOnUiThread {
                        espConnected = newState == BluetoothProfile.STATE_CONNECTED
                        statusMessage = if (espConnected) "Connected to ${esp.name}. Discovering service…"
                                        else "ESP32 connection closed (status $status)."
                    }
                    if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                }
                override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                    runOnUiThread {
                        val hasService = g.getService(serviceId) != null
                        statusMessage = if (hasService) "JARVIS ESP32 command service ready."
                                        else "ESP32 connected, but expected JARVIS service is missing. Install matching firmware."
                    }
                }
            }, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            statusMessage = "Bluetooth connect permission was denied."
        }
    }

    @Suppress("MissingPermission")
    private fun requestTargetDisconnect() {
        val target = selected
        if (target == null) { statusMessage = "Select a device first."; return }
        if (!espConnected || gatt == null) {
            statusMessage = "Connect to your ESP32 first. This command needs matching ESP32 firmware."
            return
        }
        try {
            val characteristic = gatt?.getService(serviceId)?.getCharacteristic(commandId)
            if (characteristic == null) {
                statusMessage = "ESP32 command characteristic not found. Update ESP32 firmware."
                return
            }
            val command = "DISCONNECT:${target.address}".toByteArray(Charsets.UTF_8)
            characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            characteristic.value = command
            val accepted = gatt?.writeCharacteristic(characteristic) ?: false
            statusMessage = if (accepted)
                "Disconnect request sent for ${target.name}. Actual support depends on ESP32 firmware and device protocol."
            else "Could not send request. Check the ESP32 connection."
        } catch (e: SecurityException) {
            statusMessage = "Bluetooth permission was denied."
        }
    }

    override fun onDestroy() {
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun OceanusApp(
    devices: List<SeenDevice>, scanning: Boolean, espConnected: Boolean,
    selected: SeenDevice?, status: String, onScan: () -> Unit, onSelect: (SeenDevice) -> Unit,
    onConnectEsp: () -> Unit, onDisconnectTarget: () -> Unit, onReconnect: () -> Unit
) {
    var tab by remember { mutableStateOf("Dashboard") }
    var history by remember { mutableStateOf(listOf<String>()) }
    val avg = if (devices.isEmpty()) "—" else "${devices.map { it.rssi }.average().toInt()} dBm"

    Surface(Modifier.fillMaxSize(), color = Navy) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071B33), Navy)))) {
            Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("JARVIS", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("O C E A N U S", color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("ESP32 BLUETOOTH AUDIO LAB", color = Muted, fontSize = 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (espConnected) "● ESP32 ONLINE" else "● ESP32 OFFLINE", color = if (espConnected) Green else Color(0xFFFFB454), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = onConnectEsp) { Text("CONNECT", color = Cyan) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Dashboard", "Scanner", "Monitor", "History", "Settings").forEach {
                        FilterChip(selected = tab == it, onClick = { tab = it },
                            label = { Text(it, fontSize = 10.sp) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                when (tab) {
                    "Dashboard", "Scanner" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard("BLE DEVICES", devices.size.toString(), Modifier.weight(1f))
                            MetricCard("AVG RSSI", avg, Modifier.weight(1f))
                            MetricCard("SCAN", if (scanning) "LIVE" else "IDLE", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("NEARBY BLUETOOTH DEVICES", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(onClick = onScan, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                                Icon(Icons.Default.BluetoothSearching, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp)); Text(if (scanning) "Scanning" else "Scan", fontSize = 12.sp)
                            }
                        }
                        Text("BLE advertisements only. Classic-only speakers/headsets may not appear.", color = Muted, fontSize = 10.sp)
                        Spacer(Modifier.height(6.dp))
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(devices, key = { it.address }) { device ->
                                DeviceRow(device, selected?.address == device.address) { onSelect(device) }
                            }
                            if (devices.isEmpty()) item {
                                PanelCard {
                                    Text("No scan results yet", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Tap Scan to discover nearby BLE advertisements.", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        PanelCard {
                            Text("SELECTED DEVICE", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(selected?.name ?: "Choose a device from the list", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(selected?.let { "${it.address}  •  ${it.rssi} dBm" } ?: "No device selected", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = onDisconnectTarget, modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB52C48))) {
                                    Icon(Icons.Default.BluetoothDisabled, null); Spacer(Modifier.width(4.dp)); Text("Disconnect")
                                }
                                OutlinedButton(onClick = onReconnect, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Reconnect")
                                }
                            }
                            Text("Disconnect sends an authorized request to compatible ESP32 firmware; it does not force-disconnect arbitrary devices.", color = Muted, fontSize = 9.sp)
                        }
                    }
                    "Monitor" -> {
                        PanelCard {
                            Text("SIGNAL MONITOR", color = Cyan, fontWeight = FontWeight.Bold)
                            Text("Live RSSI readings from the latest BLE scan", color = Muted, fontSize = 12.sp)
                            devices.take(12).forEach { d ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(d.name, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                    Text("${d.rssi} dBm", color = if (d.rssi > -65) Green else Cyan, fontWeight = FontWeight.Bold)
                                }
                                LinearProgressIndicator(progress = { ((d.rssi + 100) / 70f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Cyan)
                            }
                            if (devices.isEmpty()) Text("Run a scan to populate signal readings.", color = Muted)
                        }
                    }
                    "History" -> {
                        PanelCard {
                            Text("TEST HISTORY", color = Cyan, fontWeight = FontWeight.Bold)
                            Text("Scan records are kept for this app session in this starter version.", color = Muted, fontSize = 11.sp)
                            Text("Latest status: $status", color = Color.White, fontSize = 12.sp)
                        }
                    }
                    else -> {
                        PanelCard {
                            Text("SETTINGS", color = Cyan, fontWeight = FontWeight.Bold)
                            Text("App: JARVIS OCEANUS", color = Color.White)
                            Text("Connection: BLE GATT to ESP32", color = Muted, fontSize = 12.sp)
                            Text("ESP32 service UUID: 7f510001-1b15-4f0a-9a2b-6f4a524f4345", color = Muted, fontSize = 10.sp)
                            Text("OLED / two-wire trigger are configured in ESP32 firmware, not from this screen.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(status, color = Muted, fontSize = 10.sp, maxLines = 2)
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF020A14)).padding(10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("Dashboard", "Scanner", "Monitor", "History", "Settings").forEach {
                    Text(it, color = if (tab == it) Cyan else Muted, fontSize = 10.sp,
                        modifier = Modifier.clickable { tab = it }.padding(4.dp))
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    PanelCard(modifier) {
        Text(value, color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun DeviceRow(device: SeenDevice, selected: Boolean, onClick: () -> Unit) {
    PanelCard(Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Bluetooth, null, tint = Cyan, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(device.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(device.address, color = Muted, fontSize = 9.sp)
            }
            Text("${device.rssi} dBm", color = if (device.rssi > -65) Green else Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.padding(start = 6.dp))
        }
    }
}

@Composable
private fun PanelCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF164A70))) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
    }
}
