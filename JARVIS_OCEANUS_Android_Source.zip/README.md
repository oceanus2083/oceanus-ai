# JARVIS OCEANUS — Android starter project

A Kotlin + Jetpack Compose Android Studio project for the ESP32 Bluetooth Audio Laboratory.

## Included
- Dark JARVIS OCEANUS dashboard
- Android BLE advertisement scanner (10-second scan)
- Device list with address and RSSI
- Signal monitor
- ESP32 BLE GATT connection attempt
- Selected-device disconnect request button
- History and settings starter screens

## Important functional limits
1. Android BLE scanning only discovers BLE advertisements. Many Bluetooth speakers, headsets and wireless microphones use Bluetooth Classic or do not advertise identifying names; they may not appear.
2. The app does not classify a device as a speaker or microphone with certainty.
3. The Disconnect button sends `DISCONNECT:<MAC>` to the ESP32 over the custom GATT command characteristic. It only sends a request. The ESP32 firmware must implement an authorized method for a specific device and protocol. The ESP32 cannot forcibly disconnect arbitrary nearby devices.
4. Reconnect is currently a placeholder until a supported device-specific connection method is implemented.
5. Test History is a starter session/status view; persistent database history is not yet implemented.

## Open in Android Studio
1. Install Android Studio with Android SDK 35 and JDK 17.
2. Extract this ZIP.
3. Open the `JARVIS_OCEANUS_Android` folder in Android Studio.
4. Allow Gradle sync to download dependencies.
5. Connect an Android phone, enable Bluetooth, then Run.

This is source code, not a precompiled APK.

## ESP32 BLE GATT contract
The Android app searches for an ESP32/JARVIS BLE peripheral and expects:

- Service UUID: `7f510001-1b15-4f0a-9a2b-6f4a524f4345`
- Writable command characteristic UUID: `7f510002-1b15-4f0a-9a2b-6f4a524f4345`
- Command format: UTF-8 `DISCONNECT:<MAC_ADDRESS>`

The ESP32 should advertise a name containing `ESP32` or `JARVIS`.
Implement device-specific authorization and safety checks in firmware before acting on any command. Do not implement jamming or interference.

## Build an APK using only your Android phone (GitHub Actions)
This repository includes `.github/workflows/android.yml` for a cloud build.

1. Create/sign in to a GitHub account in your phone browser.
2. Create a **new public or private repository** named `JARVIS-OCEANUS`.
3. On GitHub, use **Add file → Upload files** and upload the extracted project contents (including the hidden `.github` folder). If the mobile uploader hides `.github`, use GitHub's web editor to create `.github/workflows/android.yml` from the workflow file in this ZIP.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build JARVIS OCEANUS APK**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `JARVIS-OCEANUS-debug-apk`.
8. Extract the artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser or file manager.

This produces a debug APK for testing. It is not a Play Store release. The app and ESP32 still need matching firmware for the ESP32 connection and device-control commands.
